const express = require('express')
const userController = require('../controllers/userController');
const loginController = require('../controllers/loginController');
const verifyToken = require('../middlewares/jwt');

const router = express.Router();

router.post('/dologin', loginController.doLogin);

router.get('/getusers', verifyToken, userController.getusers);
router.get('/getuser/:id', userController.getuserById);
router.post('/createuser', verifyToken, userController.createUser);
router.put('/updateuser/:id', verifyToken, userController.updateUser);
router.put('/updatepassword/:id', verifyToken, userController.updatePassword);

router.get('/', (req, res) => {
     res.send('hola mundo')
 })

module.exports = router;